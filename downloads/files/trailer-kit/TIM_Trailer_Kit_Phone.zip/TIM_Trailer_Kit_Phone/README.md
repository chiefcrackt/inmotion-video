# T.im Channel Trailer Pack

These are the new pieces for the channel trailer. They use the same cyber system as the rest of the video kit: the real traced badge, Barlow Condensed, teal/gold split glitch, band glitch, HUD brackets, scanlines and CRT switch-off. All pieces are 30 fps, and every video has its sound built in, with a matching .wav alongside.

## Pieces

| Piece | Length | Sizes | What it is |
|---|---|---|---|
| Sting, logo | 3.0s | 16:9, 9:16 | The short reveal. A charge line, the badge hits at 0.5s, the waves wipe on, and the name lands at 1.0s. Then a stutter and a CRT switch-off at 2.7s. |
| Distance Ladder | 7.0s | 16:9, 9:16 | Counts 13.1 → 26.2 → 31.1 → 62.1 → 100 (half 2025; marathon, 50K, 100K and 100 miles 2026). The 100 glitches to **DNF** at 5.5s. CRT off at 6.6s. |
| Pillar tags (×5) | 2.0s each | 16:9, 9:16 | Workouts, Trails, Food, Gear, Chats. Overlays, bottom-left: 150px above the bottom on 16:9, and clear of the bottom 400px on 9:16. Each tag has its own stab note (E, G, B, D, E going up). |
| Runner: Logo Run | 5.8s | 16:9, 9:16 | Overlay. The badge forms and the runner hops onto the ring at 1.65s. He runs over the top, and every footstrike flashes the waves and pings a rising note. He jumps off at 3.45s, and his landing at 4.05s sends a shockwave through the badge. CRT out at 5.4s. |
| Runner: Subscribe Run | 7.2s | 16:9, 9:16 | Overlay. He runs under the three buttons and punches each one from below: LIKE at 1.5s, SUBSCRIBE at 3.0s (turns gold "SUBSCRIBED"), BELL at 4.5s (rings). All three hits land on the beat at 120 BPM. CRT out at 6.65s. |
| Trailer End Card | 6.0s | 16:9 | Your handle, TRISTAN.INMOTION, big on the left (no tagline), and a slot for YouTube's Subscribe element on the right. The runner runs in and keeps running on a moving floor. |
| Trailer music | 65s | .wav | Original and synthesized, E minor, 120 BPM. Cut to the script beats (below). |

## Formats

- **Full-frame pieces** (Sting, Ladder, End Card): .mp4 (H.264 + AAC).
- **Overlays** (tags, Logo Run, Subscribe Run):
  - Phone zip: `_GreenScreen.mp4` (key out #00FF00) and `_Alpha.webm` (true transparency).
  - Desktop zip: `_ProRes4444.mov` (transparent, for Premiere, Final Cut and Resolve).
- The overlay panels and badge are fully opaque, so green screen keys cleanly. The runner's edges are anti-aliased; if you see a green fringe, add a little choke or spill suppression.

## Sound levels

Full-frame pieces peak at −3 dBFS. Overlays peak at −4 dBFS so they sit under the music. The music peaks at −3 dBFS; duck it about 10–12 dB under your voice in the on-camera sections.

## Trailer timeline (music beats)

The music is cut so each piece lands on a beat:

| Time | Script beat | Music | What goes here |
|---|---|---|---|
| 0:00–0:05.5 | Hook (VO) | Dark pad, heartbeat kick, riser | Distance Ladder at **0:00**, with its first 0.5s trimmed off. That puts DNF at 0:05.0, exactly when the music cuts out. Cut the ladder at 0:05.5 (6.0s into the clip). |
| 0:05–0:06 | Cut to black | Silence | "I didn't finish" goes over the DNF and the black. |
| 0:06 | Reveal | Drop | Sting at **0:05.5**. Its charge line plays in the silence, and its hit (0.5s in) lands on the drop at 0:06. |
| 0:09–0:20 | Who (on camera) | Light groove, mids carved | Talk to camera; duck the music. |
| 0:20 | Montage starts | Full groove plus a lift | One pillar tag per clip; cut on the 0.5s grid. The Logo Run works mid-montage, at 0:28 or 0:32 (on a bar line). |
| 0:44 | Where it's going | Breakdown (pad and pulse) | On camera. |
| 0:52–0:59 | Where it's going, into the close | Riser into the final groove at 0:56 | Subscribe Run at **0:52.0**, over the bottom of the on-camera shot. The punches land at 0:53.5, 0:55 and 0:56.5, and it switches off by 0:59, right as the end card starts. |
| 0:59–1:05 | End card | Final hit at 1:02, ring out | End card in the last 6s; YouTube end screen elements go here. |

Bars are 2.0s long and beats are 0.5s, so every multiple of 0.5s is on the grid.

## End card and YouTube

- Add a **Subscribe** end screen element in YouTube Studio. Place it over the dashed gold ring on the right, using `TIM_Trailer_EndCard_GUIDE_do_not_upload.png` as the guide.
- End screen elements only work in the last 5–20 seconds, and the video has to be at least 25 seconds long.
- No "Watch Next" panes yet. Swap in the Watch Next end screen once there are videos to point to.

## Runner

The runner is the same cut-out from the link-in-bio page (`scene/runner/` in chiefcrackt/links-inMotion), with the same gold and teal rim light. His feet are planted at all times: his stride is driven by the distance he travels, not by a clock. He's sized well under half the frame height, where the small pieces stay sharp.
