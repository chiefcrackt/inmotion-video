# T.im Logo: The Loop

A bright comet draws a gold line across the floor, curves up into a full loop and comes back around. The line becomes your logo's ring. When the circle closes, the disc fills, the three waves draw on one after another with a soft light at each tip, the name writes on, and a sheen passes across the badge.

This one is built to be smooth, not glitchy. It's rendered at **60 fps**, with eased motion throughout and no stutter at the end. The sound is melodic: as the comet goes around the loop, it plays a note up the E minor scale on a steady stride rhythm, climbing three octaves (E3 to E6) over a pad that swells until the circle closes.

| Version | Length | Sizes | Use |
|---|---|---|---|
| The Loop (overlay) | 9.3s | 16:9, 9:16 | Over footage. |
| The Loop, full-frame | 9.3s | 16:9, 9:16 | An intro or reveal on navy, with a grid floor and corner brackets. |

## Timing (same in every version)

| Time | What happens |
|---|---|
| 0.0s | The comet streaks in from the left, drawing the gold line; the pad starts. |
| 1.8s | It curves up into the loop; the notes start climbing. |
| 5.42s | The circle closes: bloom, sub drop and bell chord. The disc fills and the floor line fades away. |
| 5.55–6.6s | The waves draw on (lower, big, upper right), each with a soft bell (E, G, B). |
| 6.7–7.2s | The name writes on, with a chime. |
| 7.4–8.1s | A sheen passes across the badge. |
| 8.75–9.25s | CRT switch-off. |

## Files

- **Phone zip:** `_GreenScreen.mp4` and `_Alpha.webm` for the overlay, `.mp4` for the full-frame version, and `.wav` for both.
- **Desktop zip:** the overlay as transparent ProRes 4444 `.mov`. For the full-frame version, use the `.mp4` from the phone zip.
- **Green screen vs. transparent:** the transparent versions show the disc as tinted glass during the loop and a glow around the comet. The green-screen version drops those see-through touches so it keys cleanly.
- **60 fps:** fine in a 30 fps timeline; the timing stays the same.
- **Sound:** the overlay peaks at −4 dBFS and the full-frame version at −3 dBFS.

## Where to use it

At 9.3s it's long for the 65-second trailer, so keep the 3-second sting there. The Loop's best home is the **intro for your regular videos**.
