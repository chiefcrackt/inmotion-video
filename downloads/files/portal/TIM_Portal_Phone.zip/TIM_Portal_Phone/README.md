# T.im Runner: Portal

The runner runs into the left side of the badge. A teal glitch-ghost of him streaks through the disc, and a light sweep chases him through the waves. He bursts out the right side mid-leap, and the wordmark lands on the beat. It's the same cyber system as the rest of the kit, at 30 fps, with the sound built into every video.

| Version | Length | Sizes | Use |
|---|---|---|---|
| Portal (overlay) | 6.0s | 16:9, 9:16 | Mid-video, over footage. Transparent, with no shadows, so the green screen keys clean. |
| Portal, full-frame | 6.0s | 16:9, 9:16 | An intro or reveal on navy, with a grid floor, REC HUD and corner brackets. |

## Timing (same in every version, on the 120 BPM grid)

| Time | What happens |
|---|---|
| 0.0s | Badge forms (no wordmark yet) |
| 0.4s | Runner glitch-boots in, running |
| 1.5s | He hits the left edge: ring flare and zap |
| 1.6–2.5s | Ghost streaks through the disc; waves light up behind him |
| 2.5s | Bursts out the right side mid-leap (color split, speed lines) |
| 3.0s | Wordmark lands: sub drop and chime |
| 3.1s | He lands and keeps running |
| 5.3s | Stutter |
| 5.42–5.95s | CRT switch-off |

## Files

- **Phone zip:** the overlay as `_GreenScreen.mp4` and `_Alpha.webm`, the full-frame version as `.mp4`, and `.wav` for both.
- **Desktop zip:** the overlay as transparent ProRes 4444 `.mov`. For the full-frame version, use the `.mp4` from the phone zip; it works in any editor.
- **Sound:** the overlay peaks at −4 dBFS and the full-frame version at −3 dBFS. The full-frame version adds a sub drop when it opens.

## In the trailer

The overlay fits the montage. Start it at **0:27.0**, so the burst lands on a beat at 0:29.5 and the wordmark lands on the bar at 0:30. The full-frame version works as an intro on future videos, where it isn't competing with the trailer's hook.
