# T.im Logo: The Drop

A single gold droplet falls into still water. It splashes up a little crown of droplets, and its main ripple spreads, lifts off the surface and stands up to become your logo's ring. The disc fills, the waves surge up out of it one at a time, and the name rises into place. The badge then floats gently over its own rippling reflection while a band of light drifts through the waves.

It's calm and smooth, rendered at **60 fps**, with no glitch until the CRT switch-off at the very end. The sound follows the water: a droplet plip on impact, a soft splash, each splash droplet landing on its own E-minor note, a swell as the ring rises, a bell chord when it stands, watery surges for the waves and a warm pad underneath.

| Version | Length | Sizes | Use |
|---|---|---|---|
| The Drop (overlay) | 7.5s | 16:9, 9:16 | Over footage. A short water line and ripples, no reflection. The water line fades out once the badge stands. |
| The Drop, full-frame | 7.5s | 16:9, 9:16 | An intro on navy, with the full water surface and the mirrored, wobbling reflection. |

## Timing (same in every version)

| Time | What happens |
|---|---|
| 0.1s | A glint at the top |
| 0.25–0.85s | The droplet falls |
| 0.85s | Impact: plip, splash and crown droplets; ripples spread |
| 1.25–2.05s | The main ripple lifts and stands up as the ring |
| 2.05s | Ring stands: bell chord and bloom; the disc fills |
| 2.2 / 2.38 / 2.56s | The waves surge up (lower, big, upper right) |
| 3.0s | The name rises in, with a chime; the badge starts floating |
| 3.9–5.3s | Light drifts through the waves |
| 6.9–7.4s | CRT switch-off |

## Files

- **Phone zip:** the overlay as `_GreenScreen.mp4` and `_Alpha.webm`, the full-frame version as `.mp4`, and `.wav` for both.
- **Desktop zip:** the overlay as transparent ProRes 4444 `.mov`. For the full-frame version, use the `.mp4` from the phone zip.
- **Green screen vs. transparent:** the green-screen version draws the water line and ripples as solid lines and leaves out the glows so it keys cleanly. The transparent versions keep the soft glows.
- **60 fps:** fine in a 30 fps timeline; the timing stays the same.
- **Sound:** the overlay peaks at −4 dBFS and the full-frame version at −3 dBFS.

## Where to use it

The full-frame version is made to be the **intro for your regular videos**. At 7.5s it's shorter than The Loop. For a trailer reveal, the 3-second sting is still the tighter fit.
